Cufon.replace('.sf-menu > li > a, nav.primary > .menu > li > a', { fontFamily: 'Kozuka Gothic Pro OpenType L', hover:true });
Cufon.replace('#special-cycle strong', { fontFamily: 'KozGoPro700', hover:true });
Cufon.replace('.kwicks.horizontal li .desc h2', { fontFamily: 'KozGoPro400', textShadow:'1px 1px rgba(0,0,0,.2)' });
Cufon.replace('.primary_content_wrap h2, .recent-posts.services li h5', { fontFamily: 'Kozuka Gothic Pro OpenType L', hover:true });
Cufon.replace('h1, h3', { fontFamily: 'KozGoPro400', hover:true });